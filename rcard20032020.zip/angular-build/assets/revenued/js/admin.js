jQuery(document).ready(function() {
    jQuery('#page_template').change(function() {
        var _t = jQuery(this);

        if (_t.val() == 'page-category-template.php') {
            
        }
    });

    jQuery('#page_template').change();
});
